//
//  main.m
//  ZKGuideView新手指引功能
//
//  Created by mosaic on 2017/8/15.
//  Copyright © 2017年 mosaic. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
