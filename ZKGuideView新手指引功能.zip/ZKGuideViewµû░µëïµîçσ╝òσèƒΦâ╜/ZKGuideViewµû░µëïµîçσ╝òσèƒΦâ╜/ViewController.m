//
//  ViewController.m
//  ZKGuideView新手指引功能
//
//  Created by mosaic on 2017/8/15.
//  Copyright © 2017年 mosaic. All rights reserved.
//

#import "ViewController.h"
#import "ZKGuide.h"
#import "ZKGuideView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSMutableArray *tempArray = [NSMutableArray array];
    for (int i=0; i<=0;i++ ) {
        ZKGuide *guide = [[ZKGuide alloc]init];
        guide.guideFrame = CGRectMake(10+50*i, 100, 100, 50);
        guide.guideMessage = @"===";
        guide.buttonRect = CGRectMake(200, 100, 100, 100);
        [tempArray addObject:guide];
    }
    for (int i=0; i<=1;i++ ) {
        ZKGuide *guide = [[ZKGuide alloc]init];
        guide.guideFrame = CGRectMake(10+50*i, 100, 100, 50);
        guide.guideMessage = @"喔喔喔喔喔喔喔喔哦喔喔喔cdvshkjjkbjdbjdbjebjh";
        [tempArray addObject:guide];
    }
    for (int i=0; i<=10;i++ ) {
        ZKGuide *guide = [[ZKGuide alloc]init];
        guide.guideFrame = CGRectMake(10, 10+50*i, 100, 50);
        guide.guideMessage = @"喔喔喔喔喔喔喔喔哦喔喔喔喔喔喔喔哦我喔喔哦喔喔喔喔喔喔喔哦我喔喔哦喔喔喔喔喔喔喔哦我喔喔哦喔喔喔喔喔喔喔哦我喔喔哦喔喔喔喔喔喔喔哦我喔喔哦喔喔喔喔喔喔喔哦我";
        [tempArray addObject:guide];
    }
    ZKGuideView *guideView = [[ZKGuideView alloc]init];
    [guideView setGuideArray:tempArray];
    
    [guideView setFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width,[UIScreen mainScreen].bounds.size.height)];
    [self.view addSubview:guideView];}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
