//
//  ZKGuide.h
//  自定义UI测试
//
//  Created by mosaic on 2017/8/14.
//  Copyright © 2017年 mosaic. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ZKGuide : NSObject
@property(nonatomic,assign)CGRect guideFrame;
@property(nonatomic,copy)NSString *guideMessage;
@property(nonatomic,assign)CGRect labelRect;
@property(nonatomic,assign)CGRect buttonRect;

@end
