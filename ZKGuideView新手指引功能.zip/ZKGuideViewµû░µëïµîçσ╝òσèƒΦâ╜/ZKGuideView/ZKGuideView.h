//
//  ZKGuideView.h
//  自定义UI测试
//
//  Created by mosaic on 2017/8/14.
//  Copyright © 2017年 mosaic. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZKGuide.h"
@interface ZKGuideView : UIView

@property(nonatomic,strong)NSMutableArray <ZKGuide*>*guideArray;


@end
