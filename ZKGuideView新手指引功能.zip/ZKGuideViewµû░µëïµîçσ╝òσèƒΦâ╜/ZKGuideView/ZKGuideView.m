//
//  ZKGuideView.m
//  自定义UI测试
//
//  Created by mosaic on 2017/8/14.
//  Copyright © 2017年 mosaic. All rights reserved.
//

#import "ZKGuideView.h"
@interface ZKGuideView ()
@property(nonatomic,weak) UIButton  *knownButton;
@property(nonatomic,weak) UIImageView *arrowImgv;
@property(nonatomic,weak) CAShapeLayer *fillLayer;
@property(nonatomic,assign)NSInteger index;
@property(nonatomic,weak)UILabel *messageLable;

@end
@implementation ZKGuideView

-(instancetype)init{
    self = [super init];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.opaque = NO;
        _index = 0;
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    ZKGuide*guide = self.guideArray.firstObject;
    UIBezierPath*path =  [self setPositionWithGuide:guide];
    CAShapeLayer *fillLayer = [CAShapeLayer layer];
    fillLayer.path = path.CGPath;
    fillLayer.fillRule = kCAFillRuleEvenOdd;
    fillLayer.fillColor = [UIColor blackColor].CGColor;
    fillLayer.opacity = 0.5;
    [self.layer addSublayer:fillLayer];
    self.fillLayer = fillLayer;
    
    UIImageView *arrowImgv = [[UIImageView alloc]init];
    [self addSubview:arrowImgv];
    self.arrowImgv=arrowImgv;
    
    UIButton*knownButton = [[UIButton alloc]init];
    
    [knownButton setImage:[UIImage imageNamed:@"okBtn@2x.png"] forState:UIControlStateNormal];
    
    [knownButton addTarget:self action:@selector(knownButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:knownButton];
    self.knownButton = knownButton;
    
    UILabel *messageLable = [[UILabel alloc]init];
    [messageLable setNumberOfLines:3];
    [messageLable setFont:[UIFont systemFontOfSize:13]];
    self.messageLable = messageLable;
    [self.messageLable setTextColor:[UIColor whiteColor]];
    [self addSubview:messageLable];
    self.messageLable.preferredMaxLayoutWidth = [UIScreen mainScreen].bounds.size.width*2/3;

    [self setLablePositionWithGuide:self.guideArray.firstObject];
    
}


-(void)knownButtonClick:(UIButton*)sender{
    _index++;
    if (_index<self.guideArray.count) {
        UIBezierPath*path =  [self setPositionWithGuide:self.guideArray[_index]];
        self.fillLayer.path = path.CGPath;
        [self setLablePositionWithGuide:self.guideArray[_index]];
    }else{
        [self removeFromSuperview];
    }
}

//设置高亮位置
-(UIBezierPath*)setPositionWithGuide:(ZKGuide*)guide{

    //背景
    UIBezierPath *bezierPath = [UIBezierPath bezierPathWithRoundedRect:[UIScreen mainScreen].bounds cornerRadius:0];
    //镂空
    UIBezierPath *circlePath = [UIBezierPath bezierPathWithOvalInRect:guide.guideFrame];
    [bezierPath appendPath:circlePath];
    [bezierPath setUsesEvenOddFillRule:YES];
    return bezierPath;
}


//设置图片与文本位置
-(void)setLablePositionWithGuide:(ZKGuide*)guide{
    [self.messageLable setText:guide.guideMessage];
    CGFloat screenW = [UIScreen mainScreen].bounds.size.width;
    CGFloat screenH = [UIScreen mainScreen].bounds.size.height;
    CGRect myRect =guide.guideFrame;
    //中心点X值
    CGFloat center_x = myRect.size.width/2+myRect.origin.x;
    CGFloat center_y = myRect.size.height/2+myRect.origin.y;
    CGFloat rect_y = myRect.origin.y;
    CGFloat rect_h = myRect.size.height;
    //按钮宽高比
    CGFloat button_w = screenW/6;
    CGFloat button_H = button_w*118/140;
    CGFloat margin = 5;
    //计算箭头位置
    //中心在1号区域
    if (center_x<=screenW/2&&center_y<=screenH/2) {
        CGFloat arrowImgv_w = screenW*90/750;
        [self.arrowImgv setImage:[UIImage imageNamed:@"left_top@2x.png"]];
        [self.arrowImgv setFrame:CGRectMake(center_x, rect_y+rect_h+5,arrowImgv_w, arrowImgv_w*57/67)];
        //判断是否自定义位置
        if (guide.labelRect.size.width>0&&guide.labelRect.size.height>0) {
            [self.messageLable setFrame:guide.labelRect];
        }else{
            //文本框设置
            [self.messageLable setFrame:CGRectMake(CGRectGetMaxX(self.arrowImgv.frame)-margin, CGRectGetMaxY(self.arrowImgv.frame)+margin, 200, 60)];
            [self.messageLable sizeToFit];
            if (CGRectGetMaxX(self.messageLable.frame)>screenW*5/6) {
                CGFloat label_X = self.messageLable.frame.origin.x;
                CGFloat label_W = self.messageLable.frame.size.width;
                label_X = screenW*5/6 - label_W;
                [self.messageLable setFrame:CGRectMake(label_X, CGRectGetMaxY(self.arrowImgv.frame)+margin, 200, 60)];
                [self.messageLable sizeToFit];
            }
        }
        if (guide.buttonRect.size.width>0&&guide.buttonRect.size.height>0) {
            [self.knownButton setFrame:guide.buttonRect];
        }else{
            CGFloat knownButton_x = (self.messageLable.frame.size.width-button_w)/2+self.messageLable.frame.origin.x;
            [self.knownButton setFrame:CGRectMake(knownButton_x, CGRectGetMaxY(self.messageLable.frame)+30, button_w, button_H)];
        }
        
    }else if (center_x>screenW/2&&center_y<=screenH/2){//中心在2号区域
        CGFloat arrowImgv_H = screenW*90/750;
        CGFloat arrowImgv_W = arrowImgv_H*57/67;
        [self.arrowImgv setImage:[UIImage imageNamed:@"right_top@2x.png"]];
        [self.arrowImgv setFrame:CGRectMake(center_x-arrowImgv_W, rect_y+rect_h+5,arrowImgv_W, arrowImgv_H)];
        //文本框设置
        //判断是否自定义位置
        if (guide.labelRect.size.width>0&&guide.labelRect.size.height>0) {
            [self.messageLable setFrame:guide.labelRect];
        }else{
        
            [self.messageLable setFrame:CGRectMake(CGRectGetMaxX(self.arrowImgv.frame), CGRectGetMaxY(self.arrowImgv.frame), 200, 60)];
            [self.messageLable sizeToFit];
            [self.messageLable setFrame:CGRectMake(self.arrowImgv.frame.origin.x-self.messageLable.frame.size.width+margin, CGRectGetMaxY(self.arrowImgv.frame)+margin, 200, 60)];
            [self.messageLable sizeToFit];
            
            if (self.messageLable.frame.origin.x<screenW*1/6) {
                CGFloat label_X = self.messageLable.frame.origin.x;
                label_X = screenW*1/6;
                [self.messageLable setFrame:CGRectMake(label_X, CGRectGetMaxY(self.arrowImgv.frame)+margin, 200, 60)];
                [self.messageLable sizeToFit];
            }
        }
        
        if (guide.buttonRect.size.width>0&&guide.buttonRect.size.height>0) {
            [self.knownButton setFrame:guide.buttonRect];
        }else{
            //按钮位置
            CGFloat knownButton_x = (self.messageLable.frame.size.width-button_w)/2+self.messageLable.frame.origin.x;
            [self.knownButton setFrame:CGRectMake(knownButton_x, CGRectGetMaxY(self.messageLable.frame)+30, button_w, button_H)];
        }
       
        
    }else if (center_x<=screenW/2&&center_y>screenH/2){//中心在3号区域
        CGFloat arrowImgv_H = screenW*90/750;
        CGFloat arrowImgv_W = arrowImgv_H*57/67;
        [self.arrowImgv setImage:[UIImage imageNamed:@"left_down@2x.png"]];
        [self.arrowImgv setFrame:CGRectMake(center_x, rect_y-arrowImgv_H-5,arrowImgv_W, arrowImgv_H)];
        if (guide.labelRect.size.width>0&&guide.labelRect.size.height>0) {
            [self.messageLable setFrame:guide.labelRect];
        }else{
            //文本框设置
            CGFloat messageLable_y;
            [self.messageLable setFrame:CGRectMake(CGRectGetMaxX(self.arrowImgv.frame), CGRectGetMaxY(self.arrowImgv.frame), 200, 60)];
            [self.messageLable sizeToFit];
            //调整y坐标
            messageLable_y = self.arrowImgv.frame.origin.y - self.messageLable.frame.size.height;
            [self.messageLable setFrame:CGRectMake(CGRectGetMaxX(self.arrowImgv.frame)-margin,messageLable_y-margin, 200, 60)];
            [self.messageLable sizeToFit];
            if (CGRectGetMaxX(self.messageLable.frame)>screenW*5/6) {
                CGFloat label_X = self.messageLable.frame.origin.x;
                CGFloat label_W = self.messageLable.frame.size.width;
                label_X = screenW*5/6 - label_W;
                [self.messageLable setFrame:CGRectMake(label_X,messageLable_y-margin, 200, 60)];
                [self.messageLable sizeToFit];
            }
        }
        if (guide.buttonRect.size.width>0&&guide.buttonRect.size.height>0) {
            [self.knownButton setFrame:guide.buttonRect];
        }else{
            //按钮位置
            CGFloat knownButton_x = (self.messageLable.frame.size.width-button_w)/2+self.messageLable.frame.origin.x;
            
            [self.knownButton setFrame:CGRectMake(knownButton_x, self.messageLable.frame.origin.y-button_H-30, button_w, button_H)];
        }
        
       
        
        
       
        
    }else if (center_x>screenW/2&&center_y>screenH/2){//中心在4号区域
        CGFloat arrowImgv_W = screenW*90/750;
        CGFloat arrowImgv_H = arrowImgv_W*57/67;
        [self.arrowImgv setImage:[UIImage imageNamed:@"right_down@2x.png"]];
        [self.arrowImgv setFrame:CGRectMake(center_x-arrowImgv_W, rect_y-arrowImgv_H-5, arrowImgv_W, arrowImgv_H)];
        //文本框设置
        
        if (guide.labelRect.size.width>0&&guide.labelRect.size.height>0) {
            [self.messageLable setFrame:guide.labelRect];
        }else{
            CGFloat messageLable_y;
            CGFloat messageLable_x;
            [self.messageLable setFrame:CGRectMake(CGRectGetMaxX(self.arrowImgv.frame), CGRectGetMaxY(self.arrowImgv.frame), 200, 60)];
            [self.messageLable sizeToFit];
            //调整x和y坐标
            messageLable_x = self.arrowImgv.frame.origin.x-self.messageLable.frame.size.width;
            messageLable_y = self.arrowImgv.frame.origin.y - self.messageLable.frame.size.height;
            [self.messageLable setFrame:CGRectMake(messageLable_x+margin, messageLable_y-margin, 200, 60)];
            [self.messageLable sizeToFit];
            
            if (messageLable_x<screenW*1/6) {
                messageLable_x = screenW*1/6;
                [self.messageLable setFrame:CGRectMake(messageLable_x,messageLable_y-margin, 200, 60)];
                [self.messageLable sizeToFit];
            }
            
        }
        if (guide.buttonRect.size.width>0&&guide.buttonRect.size.height>0) {
            [self.knownButton setFrame:guide.buttonRect];
        }else{
            
            //按钮位置
            CGFloat knownButton_x = (self.messageLable.frame.size.width-button_w)/2+self.messageLable.frame.origin.x;
            
            [self.knownButton setFrame:CGRectMake(knownButton_x, self.messageLable.frame.origin.y-button_H-30, button_w, button_H)];
        }
    }
}


@end
